using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Laser
{
    public static class LaserState
    {
        public static float maxDuration = 15f;
        public static float currentDuration = 0f;
        
    }
}

